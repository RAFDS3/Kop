package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.PerformanceMode
import com.example.data.model.PrioritySettings
import com.example.data.repository.GameBoosterRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Vortex Booster", appName)
  }

  @Test
  fun `verify game booster repository initialization`() {
    val repository = GameBoosterRepository()
    val games = repository.games.value
    assertTrue("Default games list should not be empty", games.isNotEmpty())
    assertEquals(PerformanceMode.ULTRA_BEAST, repository.prioritySettings.value.mode)
  }

  @Test
  fun `verify priority settings update`() {
    val repository = GameBoosterRepository()
    repository.updatePrioritySettings(
      PrioritySettings(
        mode = PerformanceMode.BALANCED,
        autoRamCleanEnabled = true,
        autoRamCleanThresholdPercent = 75
      )
    )
    assertEquals(PerformanceMode.BALANCED, repository.prioritySettings.value.mode)
    assertEquals(75, repository.prioritySettings.value.autoRamCleanThresholdPercent)
  }
}
