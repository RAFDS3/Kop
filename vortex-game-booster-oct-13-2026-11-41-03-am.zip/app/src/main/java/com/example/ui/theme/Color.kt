package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber Gaming Palette
val CyberBg = Color(0xFF090D16)
val CyberSurface = Color(0xFF111827)
val CyberSurfaceElevated = Color(0xFF1A2234)
val CyberBorder = Color(0xFF26334D)

val NeonGreen = Color(0xFF00F59B)
val NeonCyan = Color(0xFF00E5FF)
val NeonPurple = Color(0xFF9333EA)
val NeonBlue = Color(0xFF3B82F6)
val NeonAmber = Color(0xFFF59E0B)
val NeonRed = Color(0xFFFF2A55)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val ModeBeastColor = Color(0xFFFF3366)
val ModeBalancedColor = Color(0xFF00E5FF)
val ModeBatteryColor = Color(0xFF00F59B)
val ModeCustomColor = Color(0xFFA855F7)
