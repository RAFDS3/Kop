package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessHigh
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BackgroundApp
import com.example.data.model.PerformanceMode
import com.example.data.model.PrioritySettings
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.ModeBalancedColor
import com.example.ui.theme.ModeBatteryColor
import com.example.ui.theme.ModeBeastColor
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun PriorityModeScreen(
    settings: PrioritySettings,
    backgroundApps: List<BackgroundApp>,
    whitelist: Set<String>,
    onSettingsChanged: (PrioritySettings) -> Unit,
    onToggleWhitelist: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "MODE PRIORITAS GAMING",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                color = TextPrimary
            )
            Text(
                text = "Kendalikan interupsi dan alokasi sistem saat bermain game kompetitif",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted,
                fontSize = 12.sp
            )
        }

        // Mode Selector Cards
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(
                    Triple(PerformanceMode.ULTRA_BEAST, ModeBeastColor, "🔥 Prioritas CPU & GPU 100%"),
                    Triple(PerformanceMode.BALANCED, ModeBalancedColor, "⚖️ Kestabilan Suhu & FPS 60/90"),
                    Triple(PerformanceMode.BATTERY_SAVER, ModeBatteryColor, "🔋 Dingin & Efisiensi Daya"),
                    Triple(PerformanceMode.CUSTOM, NeonPurple, "⚙️ Parameter Kustom Pengguna")
                ).forEach { (mode, color, badge) ->
                    val isSelected = settings.mode == mode
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) color.copy(alpha = 0.12f) else CyberSurface)
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) color else CyberBorder,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable { onSettingsChanged(settings.copy(mode = mode)) }
                            .padding(14.dp)
                            .testTag("mode_option_${mode.name}")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = mode.displayName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) color else TextPrimary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = badge,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = color,
                                        fontSize = 11.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = mode.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }

                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(26.dp)
                                        .clip(RoundedCornerShape(13.dp))
                                        .background(color),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color(0xFF0A0F1D),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Feature Toggles Section
        item {
            Text(
                text = "FITUR PRIORITAS & PENGATURAN",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                fontSize = 12.sp
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // Block Notifications
                    SettingSwitchRow(
                        icon = Icons.Default.NotificationsOff,
                        iconTint = NeonCyan,
                        title = "Blokir Notifikasi & Banner",
                        subtitle = "Sembunyikan popup chat dan alert saat sesi game berlangsung",
                        checked = settings.blockNotifications,
                        onCheckedChange = { onSettingsChanged(settings.copy(blockNotifications = it)) }
                    )

                    // Network Priority
                    SettingSwitchRow(
                        icon = Icons.Default.NetworkCheck,
                        iconTint = NeonGreen,
                        title = "Prioritas Latensi Jaringan",
                        subtitle = "Alokasikan bandwidth penuh untuk packet UDP game",
                        checked = settings.networkPriority,
                        onCheckedChange = { onSettingsChanged(settings.copy(networkPriority = it)) }
                    )

                    // Lock Screen Brightness
                    SettingSwitchRow(
                        icon = Icons.Default.BrightnessHigh,
                        iconTint = NeonAmber,
                        title = "Kunci Kecerahan Layar",
                        subtitle = "Cegah perubahan kecerahan otomatis yang mengganggu",
                        checked = settings.lockScreenBrightness,
                        onCheckedChange = { onSettingsChanged(settings.copy(lockScreenBrightness = it)) }
                    )

                    // Auto RAM Clean Toggle & Threshold Slider
                    Column {
                        SettingSwitchRow(
                            icon = Icons.Default.CleaningServices,
                            iconTint = NeonCyan,
                            title = "Pembersih RAM Otomatis Saat Main",
                            subtitle = "Secara otomatis membersihkan RAM jika melebihi batas",
                            checked = settings.autoRamCleanEnabled,
                            onCheckedChange = { onSettingsChanged(settings.copy(autoRamCleanEnabled = it)) }
                        )

                        if (settings.autoRamCleanEnabled) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Batas Pemicu Pembersihan RAM:", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text("${settings.autoRamCleanThresholdPercent}%", style = MaterialTheme.typography.labelSmall, color = NeonCyan, fontWeight = FontWeight.Bold)
                            }
                            Slider(
                                value = settings.autoRamCleanThresholdPercent.toFloat(),
                                onValueChange = { onSettingsChanged(settings.copy(autoRamCleanThresholdPercent = it.toInt())) },
                                valueRange = 65f..90f,
                                steps = 4,
                                colors = SliderDefaults.colors(
                                    thumbColor = NeonCyan,
                                    activeTrackColor = NeonCyan,
                                    inactiveTrackColor = CyberSurfaceElevated
                                )
                            )
                        }
                    }

                    // Automatic Overheat Warning Toggle & Threshold Slider
                    Column {
                        SettingSwitchRow(
                            icon = Icons.Default.Thermostat,
                            iconTint = ModeBeastColor,
                            title = "Notifikasi Peringatan Suhu Otomatis",
                            subtitle = "Beri peringatan saat suhu perangkat mendekati overheat",
                            checked = true,
                            onCheckedChange = {}
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Batas Alarm Suhu Panas:", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            Text("${String.format("%.1f", settings.overheatAlarmThresholdCelsius)}°C", style = MaterialTheme.typography.labelSmall, color = ModeBeastColor, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = settings.overheatAlarmThresholdCelsius,
                            onValueChange = { onSettingsChanged(settings.copy(overheatAlarmThresholdCelsius = it)) },
                            valueRange = 39f..46f,
                            steps = 6,
                            colors = SliderDefaults.colors(
                                thumbColor = ModeBeastColor,
                                activeTrackColor = ModeBeastColor,
                                inactiveTrackColor = CyberSurfaceElevated
                            )
                        )
                    }

                    // Haptic feedback
                    SettingSwitchRow(
                        icon = Icons.Default.Vibration,
                        iconTint = NeonPurple,
                        title = "Umpan Balik Haptic Gaming",
                        subtitle = "Getaran responsif saat boost dan status kritis",
                        checked = settings.hapticFeedback,
                        onCheckedChange = { onSettingsChanged(settings.copy(hapticFeedback = it)) }
                    )
                }
            }
        }

        // Whitelist Background Apps
        item {
            Text(
                text = "WHITELIST APLIKASI LATAR BELAKANG",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                fontSize = 12.sp
            )
            Text(
                text = "Aplikasi berikut TIDAK akan ditutup saat pembersihan RAM otomatis",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted,
                fontSize = 11.sp
            )
        }

        items(backgroundApps) { app ->
            val isWhitelisted = whitelist.contains(app.packageName) || app.isWhitelisted
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(CyberSurface)
                    .border(1.dp, if (isWhitelisted) NeonGreen.copy(alpha = 0.5f) else CyberBorder, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = app.name,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "${app.category} • ~${app.memoryUsageMb} MB",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    Switch(
                        checked = isWhitelisted,
                        onCheckedChange = { onToggleWhitelist(app.packageName) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonGreen,
                            checkedTrackColor = NeonGreen.copy(alpha = 0.3f),
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = CyberSurfaceElevated
                        )
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun SettingSwitchRow(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconTint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontSize = 13.sp
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = iconTint,
                checkedTrackColor = iconTint.copy(alpha = 0.3f),
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = CyberSurfaceElevated
            )
        )
    }
}
