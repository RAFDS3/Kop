package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.GeminiOptimizerService
import com.example.data.model.BackgroundApp
import com.example.data.model.BatteryThermalStats
import com.example.data.model.BoostRecord
import com.example.data.model.CpuStats
import com.example.data.model.DisplayStats
import com.example.data.model.GameItem
import com.example.data.model.NetworkPingStats
import com.example.data.model.PerformanceMode
import com.example.data.model.PrioritySettings
import com.example.data.model.RamStats
import com.example.data.model.ThermalStatus
import com.example.data.repository.GameBoosterRepository
import com.example.data.system.SystemMonitorManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class UiState(
    val ramStats: RamStats = RamStats(8192, 4950, 3242, 60),
    val batteryThermal: BatteryThermalStats = BatteryThermalStats(36.5f, 78, false, "Baik (Optimal)", 3950, ThermalStatus.OPTIMAL),
    val cpuStats: CpuStats = CpuStats(42, 8, "Qualcomm Snapdragon 8 Gen", "Dynamic Interactive"),
    val displayStats: DisplayStats = DisplayStats(120, "1080 x 2400 px"),
    val pingStats: NetworkPingStats = NetworkPingStats(28, "Wi-Fi (Ultra Fast)", true, "Sangat Baik (Ideal Kompetitif)"),
    val backgroundApps: List<BackgroundApp> = emptyList(),
    val isBoosting: Boolean = false,
    val lastBoostResult: BoostRecord? = null,
    val isAiAnalyzing: Boolean = false,
    val isFastCoolingActive: Boolean = false,
    val showOverheatDialog: Boolean = false,
    val showAddGameDialog: Boolean = false,
    val showGameDetailDialog: GameItem? = null,
    val selectedTab: Int = 0 // 0: Dashboard, 1: Games, 2: Priority, 3: AI, 4: Thermal
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val monitorManager = SystemMonitorManager(application)
    private val repository = GameBoosterRepository()
    private val aiService = GeminiOptimizerService()

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    val games = repository.games
    val prioritySettings = repository.prioritySettings
    val boostHistory = repository.boostHistory
    val aiOptimization = repository.aiOptimization
    val whitelist = repository.whitelist

    private var monitorJob: Job? = null

    init {
        _uiState.update {
            it.copy(
                ramStats = monitorManager.getRamStats(),
                batteryThermal = monitorManager.getBatteryThermalStats(),
                cpuStats = monitorManager.getCpuStats(),
                displayStats = monitorManager.getDisplayStats(),
                backgroundApps = monitorManager.getDetectedBackgroundApps()
            )
        }
        startMonitoringLoop()
    }

    private fun startMonitoringLoop() {
        monitorJob?.cancel()
        monitorJob = viewModelScope.launch {
            var pingCounter = 0
            while (isActive) {
                val ram = monitorManager.getRamStats()
                val thermal = monitorManager.getBatteryThermalStats()
                val cpu = monitorManager.getCpuStats()

                // Check auto-ram clean
                val settings = repository.prioritySettings.value
                val now = System.currentTimeMillis()
                if (settings.autoRamCleanEnabled &&
                    ram.usagePercent >= settings.autoRamCleanThresholdPercent &&
                    now - repository.lastAutoCleanTimestamp > 45000L
                ) {
                    repository.lastAutoCleanTimestamp = now
                    triggerAutoRamClean()
                }

                // Check thermal overheat notification
                if (thermal.tempCelsius >= settings.overheatAlarmThresholdCelsius &&
                    now - repository.lastOverheatNotificationTimestamp > 60000L
                ) {
                    repository.lastOverheatNotificationTimestamp = now
                    monitorManager.triggerOverheatWarningNotification(thermal.tempCelsius)
                    _uiState.update { it.copy(showOverheatDialog = true) }
                }

                _uiState.update { current ->
                    current.copy(
                        ramStats = ram,
                        batteryThermal = thermal,
                        cpuStats = cpu
                    )
                }

                // Measure ping every ~4 seconds
                if (pingCounter % 2 == 0) {
                    val ping = monitorManager.measureNetworkPing()
                    _uiState.update { it.copy(pingStats = ping) }
                }
                pingCounter++

                delay(2000L)
            }
        }
    }

    fun selectTab(index: Int) {
        _uiState.update { it.copy(selectedTab = index) }
    }

    fun triggerTurboBoost(triggerSource: String = "Manual") {
        viewModelScope.launch {
            _uiState.update { it.copy(isBoosting = true) }
            delay(1200L) // Visual boost turbo sequence

            val record = monitorManager.executeRamCleaning(
                triggerSource = triggerSource,
                whitelistPackages = repository.whitelist.value
            )
            repository.addBoostRecord(record)

            val updatedRam = monitorManager.getRamStats()
            val updatedThermal = monitorManager.getBatteryThermalStats()

            _uiState.update {
                it.copy(
                    isBoosting = false,
                    lastBoostResult = record,
                    ramStats = updatedRam,
                    batteryThermal = updatedThermal
                )
            }
        }
    }

    private fun triggerAutoRamClean() {
        viewModelScope.launch {
            val record = monitorManager.executeRamCleaning(
                triggerSource = "Auto Clean (Batas ${repository.prioritySettings.value.autoRamCleanThresholdPercent}%)",
                whitelistPackages = repository.whitelist.value
            )
            repository.addBoostRecord(record)
            _uiState.update {
                it.copy(
                    ramStats = monitorManager.getRamStats(),
                    lastBoostResult = record
                )
            }
        }
    }

    fun dismissBoostResultDialog() {
        _uiState.update { it.copy(lastBoostResult = null) }
    }

    fun setPerformanceMode(mode: PerformanceMode) {
        repository.setPerformanceMode(mode)
    }

    fun updatePrioritySettings(newSettings: PrioritySettings) {
        repository.updatePrioritySettings(newSettings)
    }

    fun toggleAppWhitelist(packageName: String) {
        repository.toggleAppWhitelist(packageName)
    }

    fun runAiOptimization(game: GameItem) {
        viewModelScope.launch {
            _uiState.update { it.copy(isAiAnalyzing = true) }
            val currentRam = _uiState.value.ramStats
            val currentThermal = _uiState.value.batteryThermal
            val display = _uiState.value.displayStats

            val result = aiService.analyzeAndOptimizeGame(
                gameTitle = game.name,
                gameGenre = game.category,
                currentRamUsedMb = currentRam.usedMb,
                totalRamMb = currentRam.totalMb,
                currentTempCelsius = currentThermal.tempCelsius,
                batteryPercent = currentThermal.batteryPercent,
                refreshRateHz = display.refreshRateHz
            )

            repository.setAiOptimization(result)
            _uiState.update { it.copy(isAiAnalyzing = false) }
        }
    }

    fun applyAiOptimizationProfile() {
        val ai = repository.aiOptimization.value ?: return
        repository.setPerformanceMode(ai.recommendedMode)
        repository.updatePrioritySettings(
            repository.prioritySettings.value.copy(
                mode = ai.recommendedMode,
                overheatAlarmThresholdCelsius = ai.thermalLimitCelsius,
                networkPriority = true,
                blockNotifications = true
            )
        )
        triggerTurboBoost("AI Smart Tuning")
    }

    fun launchGameWithBoost(game: GameItem) {
        viewModelScope.launch {
            repository.recordGamePlayed(game.id)
            repository.setPerformanceMode(game.customMode)
            triggerTurboBoost("Peluncuran: ${game.name}")
        }
    }

    fun toggleFastCooling() {
        val nextState = !_uiState.value.isFastCoolingActive
        _uiState.update { it.copy(isFastCoolingActive = nextState) }
        if (nextState) {
            repository.setPerformanceMode(PerformanceMode.BATTERY_SAVER)
            viewModelScope.launch {
                // Simulate thermal cooling down
                delay(3000L)
                val current = monitorManager.getBatteryThermalStats()
                val cooled = current.copy(tempCelsius = (current.tempCelsius - 1.8f).coerceAtLeast(29.0f))
                _uiState.update { it.copy(batteryThermal = cooled) }
            }
        }
    }

    fun dismissOverheatDialog() {
        _uiState.update { it.copy(showOverheatDialog = false) }
    }

    fun setShowAddGameDialog(show: Boolean) {
        _uiState.update { it.copy(showAddGameDialog = show) }
    }

    fun setSelectedGameDetail(game: GameItem?) {
        _uiState.update { it.copy(showGameDetailDialog = game) }
    }

    fun addCustomGame(name: String, category: String, targetFps: Int) {
        val newGame = GameItem(
            id = System.currentTimeMillis().toString(),
            name = name,
            packageName = "com.custom." + name.lowercase().replace(" ", ""),
            category = category,
            targetFps = targetFps,
            customMode = PerformanceMode.ULTRA_BEAST,
            iconEmoji = "🕹️"
        )
        repository.addGame(newGame)
        setShowAddGameDialog(false)
    }

    fun updateGameConfig(gameId: String, targetFps: Int, mode: PerformanceMode, resolution: String) {
        repository.updateGameConfig(gameId, targetFps, mode, resolution)
    }

    fun removeGame(gameId: String) {
        repository.removeGame(gameId)
        _uiState.update { it.copy(showGameDetailDialog = null) }
    }
}
