package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val GameBoosterDarkColorScheme = darkColorScheme(
    primary = NeonGreen,
    onPrimary = Color(0xFF021B10),
    primaryContainer = Color(0xFF064E3B),
    onPrimaryContainer = Color(0xFFA7F3D0),

    secondary = NeonCyan,
    onSecondary = Color(0xFF002028),
    secondaryContainer = Color(0xFF083344),
    onSecondaryContainer = Color(0xFFA5F3FC),

    tertiary = NeonPurple,
    onTertiary = Color(0xFF250346),
    tertiaryContainer = Color(0xFF4C1D95),
    onTertiaryContainer = Color(0xFFDDD6FE),

    background = CyberBg,
    onBackground = TextPrimary,

    surface = CyberSurface,
    onSurface = TextPrimary,
    surfaceVariant = CyberSurfaceElevated,
    onSurfaceVariant = TextSecondary,

    outline = CyberBorder,
    outlineVariant = Color(0xFF1E293B),

    error = NeonRed,
    onError = Color.White
)

@Composable
fun VortexBoosterTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GameBoosterDarkColorScheme,
        typography = Typography,
        content = content
    )
}
