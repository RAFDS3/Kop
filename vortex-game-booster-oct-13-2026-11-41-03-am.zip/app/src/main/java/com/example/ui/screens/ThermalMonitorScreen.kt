package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BatteryThermalStats
import com.example.data.model.BoostRecord
import com.example.data.model.ThermalStatus
import com.example.ui.components.CircularGauge
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ThermalMonitorScreen(
    thermalStats: BatteryThermalStats,
    isFastCoolingActive: Boolean,
    alarmThresholdCelsius: Float,
    boostHistory: List<BoostRecord>,
    onToggleFastCooling: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tempColor = when (thermalStats.thermalStatus) {
        ThermalStatus.OVERHEAT -> NeonRed
        ThermalStatus.WARM -> NeonAmber
        ThermalStatus.OPTIMAL -> NeonGreen
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "MONITOR SUHU REAL-TIME",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                color = TextPrimary
            )
            Text(
                text = "Perlindungan termal aktif mencegah thermal throttling saat gaming berat",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted,
                fontSize = 12.sp
            )
        }

        // Center Gauge & Thermal Status Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, tempColor.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularGauge(
                        value = ((thermalStats.tempCelsius - 20f) / 30f * 100f).coerceIn(0f, 100f),
                        valueText = "${String.format("%.1f", thermalStats.tempCelsius)}°C",
                        labelText = "SENSOR BATERAI & SOC",
                        subText = when (thermalStats.thermalStatus) {
                            ThermalStatus.OVERHEAT -> "STATUS: OVERHEAT"
                            ThermalStatus.WARM -> "STATUS: HANGAT"
                            ThermalStatus.OPTIMAL -> "STATUS: NORMAL"
                        },
                        gaugeColor = tempColor,
                        size = 170.dp,
                        strokeWidth = 14.dp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Batas Alarm", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            Text("${String.format("%.1f", alarmThresholdCelsius)}°C", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = NeonAmber)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Tegangan Sensor", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            Text("${thermalStats.voltageMv} mV", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = NeonCyan)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Kesehatan Baterai", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            Text(thermalStats.health, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = NeonGreen)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Fast Cooling Button
                    Button(
                        onClick = onToggleFastCooling,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isFastCoolingActive) NeonCyan else CyberSurfaceElevated,
                            contentColor = if (isFastCoolingActive) Color(0xFF0A0F1D) else NeonCyan
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("fast_cooling_toggle_button")
                    ) {
                        Icon(imageVector = Icons.Default.AcUnit, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isFastCoolingActive) "MODE PENDINGINAN CEPAT AKTIF (TURUNKAN LOAD)" else "AKTIFKAN PENDINGINAN CEPAT",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Tips & Thermal Prevention Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Tips Menjaga Suhu Dingin Saat Gaming:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }

                    Text("1. Lepas casing pelindung smartphone jika bermain game berat lebih dari 30 menit.", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 12.sp)
                    Text("2. Hindari bermain game sambil mengisi daya dengan adaptor fast-charging 30W+.", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 12.sp)
                    Text("3. Turunkan FPS target dari 120 ke 90 atau 60 FPS jika suhu ruangan hangat.", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 12.sp)
                    Text("4. Gunakan fitur 'Pembersih RAM Otomatis' agar tidak ada aplikasi background yang diam-diam menyedot CPU.", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 12.sp)
                }
            }
        }

        // Boost & Thermal Drop History
        item {
            Text(
                text = "RIWAYAT OPTIMASI & PENURUNAN SUHU",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                fontSize = 12.sp
            )
        }

        items(boostHistory.take(8)) { record ->
            val dateFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            val timeStr = dateFormat.format(Date(record.timestamp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(CyberSurface)
                    .border(1.dp, CyberBorder, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.History, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(record.triggerSource, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(timeStr, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${record.appsClosedCount} aplikasi ditutup • ${record.freedRamMb} MB dibebaskan",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(NeonGreen.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${String.format("%.1f", record.temperatureBefore)}°C ➔ ${String.format("%.1f", record.temperatureAfter)}°C",
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
