package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GameItem
import com.example.data.model.PerformanceMode
import com.example.data.model.ThermalStatus
import com.example.ui.UiState
import com.example.ui.components.CircularGauge
import com.example.ui.components.MetricCard
import com.example.ui.components.OverheatAlertBanner
import com.example.ui.components.TurboBoostButton
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.ModeBalancedColor
import com.example.ui.theme.ModeBatteryColor
import com.example.ui.theme.ModeBeastColor
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun DashboardScreen(
    uiState: UiState,
    currentMode: PerformanceMode,
    games: List<GameItem>,
    onBoostClick: () -> Unit,
    onCoolingClick: () -> Unit,
    onModeSelect: (PerformanceMode) -> Unit,
    onLaunchGame: (GameItem) -> Unit,
    onOpenGamesTab: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Active Mode Bar & Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "VORTEX BOOSTER",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary,
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = "Sistem Gaming Siap Tempur",
                        style = MaterialTheme.typography.bodySmall,
                        color = NeonGreen,
                        fontSize = 12.sp
                    )
                }

                // Mode pill badge
                val modeColor = when (currentMode) {
                    PerformanceMode.ULTRA_BEAST -> ModeBeastColor
                    PerformanceMode.BALANCED -> ModeBalancedColor
                    PerformanceMode.BATTERY_SAVER -> ModeBatteryColor
                    PerformanceMode.CUSTOM -> NeonPurple
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(modeColor.copy(alpha = 0.2f))
                        .border(1.dp, modeColor, RoundedCornerShape(20.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = currentMode.displayName.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = modeColor,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Overheat Warning Banner (if warm or hot)
        item {
            OverheatAlertBanner(
                temperatureCelsius = uiState.batteryThermal.tempCelsius,
                thermalStatus = uiState.batteryThermal.thermalStatus,
                isFastCoolingActive = uiState.isFastCoolingActive,
                onCoolingClick = onCoolingClick
            )
        }

        // Circular Gauges Row
        item {
            val ramColor = when {
                uiState.ramStats.usagePercent > 80 -> NeonRed
                uiState.ramStats.usagePercent > 65 -> NeonAmber
                else -> NeonCyan
            }

            val tempColor = when (uiState.batteryThermal.thermalStatus) {
                ThermalStatus.OVERHEAT -> NeonRed
                ThermalStatus.WARM -> NeonAmber
                ThermalStatus.OPTIMAL -> NeonGreen
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(CyberSurface)
                    .border(1.dp, CyberBorder, RoundedCornerShape(20.dp))
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularGauge(
                    value = uiState.ramStats.usagePercent.toFloat(),
                    valueText = "${uiState.ramStats.usagePercent}%",
                    labelText = "RAM DIGUNAKAN",
                    subText = "${uiState.ramStats.freeMb} MB Bebas",
                    gaugeColor = ramColor,
                    size = 140.dp
                )

                CircularGauge(
                    value = ((uiState.batteryThermal.tempCelsius - 20f) / 30f * 100f).coerceIn(0f, 100f),
                    valueText = "${String.format("%.1f", uiState.batteryThermal.tempCelsius)}°C",
                    labelText = "SUHU PERANGKAT",
                    subText = when (uiState.batteryThermal.thermalStatus) {
                        ThermalStatus.OVERHEAT -> "Overheat!"
                        ThermalStatus.WARM -> "Hangat"
                        ThermalStatus.OPTIMAL -> "Dingin & Stabil"
                    },
                    gaugeColor = tempColor,
                    size = 140.dp
                )
            }
        }

        // Big Turbo Boost CTA
        item {
            TurboBoostButton(
                isBoosting = uiState.isBoosting,
                onBoostClick = onBoostClick
            )
        }

        // 4 Key Metric Cards
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "Beban CPU",
                        value = "${uiState.cpuStats.loadPercent}%",
                        subValue = "${uiState.cpuStats.coreCount} Cores Aktif",
                        icon = Icons.Default.Speed,
                        accentColor = NeonCyan,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Latensi Jaringan",
                        value = "${uiState.pingStats.latencyMs} ms",
                        subValue = uiState.pingStats.quality,
                        icon = Icons.Default.Wifi,
                        accentColor = if (uiState.pingStats.latencyMs < 60) NeonGreen else NeonAmber,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "Refresh Rate Layar",
                        value = "${uiState.displayStats.refreshRateHz} Hz",
                        subValue = "Lancar Tanpa Tearing",
                        icon = Icons.Default.Memory,
                        accentColor = NeonPurple,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Daya Baterai",
                        value = "${uiState.batteryThermal.batteryPercent}%",
                        subValue = if (uiState.batteryThermal.isCharging) "Mengisi Cepat" else uiState.batteryThermal.health,
                        icon = Icons.Default.BatteryChargingFull,
                        accentColor = NeonGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Quick Game Launch Strip
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(CyberSurface)
                    .border(1.dp, CyberBorder, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PELUNCUR CEPAT DENGAN BOOST",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "Lihat Semua",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable(onClick = onOpenGamesTab)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(games.take(5)) { game ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(CyberSurfaceElevated)
                                .border(1.dp, CyberBorder, RoundedCornerShape(14.dp))
                                .clickable { onLaunchGame(game) }
                                .padding(10.dp)
                                .testTag("quick_launch_${game.id}")
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.width(105.dp)
                            ) {
                                Text(
                                    text = game.iconEmoji,
                                    fontSize = 28.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = game.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    maxLines = 1,
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(NeonGreen.copy(alpha = 0.2f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${game.targetFps} FPS",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = NeonGreen,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Background App Process Manager Preview
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(CyberSurface)
                    .border(1.dp, CyberBorder, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Aplikasi Latar Belakang Terdeteksi",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${uiState.backgroundApps.size} proses menggunakan ~1.2 GB RAM",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    }

                    Button(
                        onClick = onBoostClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberSurfaceElevated,
                            contentColor = NeonCyan
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Tutup Semua", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
