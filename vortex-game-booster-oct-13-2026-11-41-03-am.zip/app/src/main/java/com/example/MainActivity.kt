package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.components.BoostResultDialog
import com.example.ui.screens.AddGameDialog
import com.example.ui.screens.AiOptimizerScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.GameConfigDialog
import com.example.ui.screens.GamesScreen
import com.example.ui.screens.PriorityModeScreen
import com.example.ui.screens.ThermalMonitorScreen
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.VortexBoosterTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            VortexBoosterTheme {
                GameBoosterApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun GameBoosterApp(viewModel: MainViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val games by viewModel.games.collectAsStateWithLifecycle()
    val prioritySettings by viewModel.prioritySettings.collectAsStateWithLifecycle()
    val boostHistory by viewModel.boostHistory.collectAsStateWithLifecycle()
    val aiOptimization by viewModel.aiOptimization.collectAsStateWithLifecycle()
    val whitelist by viewModel.whitelist.collectAsStateWithLifecycle()

    // Request notification permission on Android 13+
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // Back handling: If on sub-tabs, back goes to Dashboard
    if (uiState.selectedTab != 0) {
        BackHandler {
            viewModel.selectTab(0)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = com.example.ui.theme.CyberBg,
        bottomBar = {
            NavigationBar(
                containerColor = CyberSurface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(width = 1.dp, color = CyberBorder)
            ) {
                NavigationBarItem(
                    selected = uiState.selectedTab == 0,
                    onClick = { viewModel.selectTab(0) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = stringResource(R.string.tab_dashboard)
                        )
                    },
                    label = {
                        Text(
                            text = stringResource(R.string.tab_dashboard),
                            fontSize = 11.sp,
                            fontWeight = if (uiState.selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NeonGreen,
                        selectedTextColor = NeonGreen,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = NeonGreen.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("tab_dashboard")
                )

                NavigationBarItem(
                    selected = uiState.selectedTab == 1,
                    onClick = { viewModel.selectTab(1) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.SportsEsports,
                            contentDescription = stringResource(R.string.tab_games)
                        )
                    },
                    label = {
                        Text(
                            text = stringResource(R.string.tab_games),
                            fontSize = 11.sp,
                            fontWeight = if (uiState.selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NeonCyan,
                        selectedTextColor = NeonCyan,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = NeonCyan.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("tab_games")
                )

                NavigationBarItem(
                    selected = uiState.selectedTab == 2,
                    onClick = { viewModel.selectTab(2) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = stringResource(R.string.tab_priority)
                        )
                    },
                    label = {
                        Text(
                            text = stringResource(R.string.tab_priority),
                            fontSize = 11.sp,
                            fontWeight = if (uiState.selectedTab == 2) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = com.example.ui.theme.NeonPurple,
                        selectedTextColor = com.example.ui.theme.NeonPurple,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = com.example.ui.theme.NeonPurple.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("tab_priority")
                )

                NavigationBarItem(
                    selected = uiState.selectedTab == 3,
                    onClick = { viewModel.selectTab(3) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = stringResource(R.string.tab_ai)
                        )
                    },
                    label = {
                        Text(
                            text = stringResource(R.string.tab_ai),
                            fontSize = 11.sp,
                            fontWeight = if (uiState.selectedTab == 3) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NeonGreen,
                        selectedTextColor = NeonGreen,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = NeonGreen.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("tab_ai")
                )

                NavigationBarItem(
                    selected = uiState.selectedTab == 4,
                    onClick = { viewModel.selectTab(4) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Thermostat,
                            contentDescription = stringResource(R.string.tab_thermal)
                        )
                    },
                    label = {
                        Text(
                            text = stringResource(R.string.tab_thermal),
                            fontSize = 11.sp,
                            fontWeight = if (uiState.selectedTab == 4) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = if (uiState.batteryThermal.tempCelsius >= prioritySettings.overheatAlarmThresholdCelsius) NeonRed else NeonCyan,
                        selectedTextColor = if (uiState.batteryThermal.tempCelsius >= prioritySettings.overheatAlarmThresholdCelsius) NeonRed else NeonCyan,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = NeonCyan.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("tab_thermal")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (uiState.selectedTab) {
                0 -> DashboardScreen(
                    uiState = uiState,
                    currentMode = prioritySettings.mode,
                    games = games,
                    onBoostClick = { viewModel.triggerTurboBoost("Manual") },
                    onCoolingClick = { viewModel.toggleFastCooling() },
                    onModeSelect = { viewModel.setPerformanceMode(it) },
                    onLaunchGame = { viewModel.launchGameWithBoost(it) },
                    onOpenGamesTab = { viewModel.selectTab(1) }
                )
                1 -> GamesScreen(
                    games = games,
                    onLaunchGame = { viewModel.launchGameWithBoost(it) },
                    onConfigureGame = { viewModel.setSelectedGameDetail(it) },
                    onAiOptimizeGame = {
                        viewModel.selectTab(3)
                        viewModel.runAiOptimization(it)
                    },
                    onAddGameClick = { viewModel.setShowAddGameDialog(true) }
                )
                2 -> PriorityModeScreen(
                    settings = prioritySettings,
                    backgroundApps = uiState.backgroundApps,
                    whitelist = whitelist,
                    onSettingsChanged = { viewModel.updatePrioritySettings(it) },
                    onToggleWhitelist = { viewModel.toggleAppWhitelist(it) }
                )
                3 -> AiOptimizerScreen(
                    uiState = uiState,
                    games = games,
                    aiResult = aiOptimization,
                    onRunAiAnalysis = { viewModel.runAiOptimization(it) },
                    onApplyAiProfile = { viewModel.applyAiOptimizationProfile() }
                )
                4 -> ThermalMonitorScreen(
                    thermalStats = uiState.batteryThermal,
                    isFastCoolingActive = uiState.isFastCoolingActive,
                    alarmThresholdCelsius = prioritySettings.overheatAlarmThresholdCelsius,
                    boostHistory = boostHistory,
                    onToggleFastCooling = { viewModel.toggleFastCooling() }
                )
            }
        }
    }

    // Boost Result Dialog
    uiState.lastBoostResult?.let { record ->
        BoostResultDialog(
            record = record,
            onDismiss = { viewModel.dismissBoostResultDialog() }
        )
    }

    // Overheat Alert Emergency Dialog
    if (uiState.showOverheatDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissOverheatDialog() },
            containerColor = CyberSurface,
            title = {
                Text(
                    text = "⚠️ Suhu Perangkat Melebihi Batas!",
                    fontWeight = FontWeight.Bold,
                    color = NeonRed
                )
            },
            text = {
                Text(
                    text = "Suhu saat ini mencapai ${String.format("%.1f", uiState.batteryThermal.tempCelsius)}°C. Disarankan untuk mengaktifkan Pendinginan Cepat atau mengistirahatkan perangkat beberapa menit.",
                    color = TextPrimary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.toggleFastCooling()
                        viewModel.dismissOverheatDialog()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color(0xFF0A0F1D))
                ) {
                    Text("Aktifkan Pendinginan Cepat", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissOverheatDialog() }) {
                    Text("Tutup", color = TextMuted)
                }
            }
        )
    }

    // Add Game Dialog
    if (uiState.showAddGameDialog) {
        AddGameDialog(
            onDismiss = { viewModel.setShowAddGameDialog(false) },
            onAdd = { name, category, targetFps ->
                viewModel.addCustomGame(name, category, targetFps)
            }
        )
    }

    // Game Config Dialog
    uiState.showGameDetailDialog?.let { game ->
        GameConfigDialog(
            game = game,
            onDismiss = { viewModel.setSelectedGameDetail(null) },
            onSave = { targetFps, mode, res ->
                viewModel.updateGameConfig(game.id, targetFps, mode, res)
                viewModel.setSelectedGameDetail(null)
            },
            onDelete = {
                viewModel.removeGame(game.id)
            }
        )
    }
}
