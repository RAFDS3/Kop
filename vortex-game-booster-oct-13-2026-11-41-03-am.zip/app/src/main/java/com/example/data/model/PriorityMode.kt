package com.example.data.model

enum class PerformanceMode(val displayName: String, val subtitle: String) {
    ULTRA_BEAST("Ultra Beast", "Performa CPU & GPU maksimal untuk FPS tertinggi tanpa kompromi"),
    BALANCED("Seimbang", "Rasio ideal antara kelancaran gameplay dan efisiensi baterai"),
    BATTERY_SAVER("Hemat Daya", "Mengurangi frekuensi CPU untuk sesi bermain yang lebih dingin dan tahan lama"),
    CUSTOM("Kustom", "Konfigurasi parameter manual sesuai preferensi kamu")
}

data class PrioritySettings(
    val mode: PerformanceMode = PerformanceMode.ULTRA_BEAST,
    val blockNotifications: Boolean = true,
    val rejectIncomingCalls: Boolean = false,
    val lockScreenBrightness: Boolean = true,
    val brightnessLevel: Float = 0.85f,
    val lockMaxRefreshRate: Boolean = true,
    val networkPriority: Boolean = true,
    val autoRamCleanEnabled: Boolean = true,
    val autoRamCleanThresholdPercent: Int = 80,
    val overheatAlarmThresholdCelsius: Float = 42.0f,
    val autoCoolingMode: Boolean = true,
    val hapticFeedback: Boolean = true
)
