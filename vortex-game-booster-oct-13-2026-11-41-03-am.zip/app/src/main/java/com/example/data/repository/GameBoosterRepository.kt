package com.example.data.repository

import com.example.data.model.AiOptimizationResult
import com.example.data.model.BackgroundApp
import com.example.data.model.BoostRecord
import com.example.data.model.GameItem
import com.example.data.model.PerformanceMode
import com.example.data.model.PrioritySettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class GameBoosterRepository {

    private val _games = MutableStateFlow<List<GameItem>>(
        listOf(
            GameItem("1", "Mobile Legends: Bang Bang", "com.mobile.legends", "MOBA", 120, "100%", PerformanceMode.ULTRA_BEAST, true, 145, System.currentTimeMillis() - 3600000, "⚔️"),
            GameItem("2", "PUBG Mobile", "com.tencent.ig", "Battle Royale", 90, "100%", PerformanceMode.ULTRA_BEAST, true, 210, System.currentTimeMillis() - 7200000, "🪂"),
            GameItem("3", "Free Fire MAX", "com.dts.freefiremax", "Battle Royale", 90, "100%", PerformanceMode.ULTRA_BEAST, true, 95, System.currentTimeMillis() - 18000000, "🔥"),
            GameItem("4", "Genshin Impact", "com.miHoYo.GenshinImpact", "Action RPG", 60, "85%", PerformanceMode.BALANCED, true, 340, System.currentTimeMillis() - 86400000, "✨"),
            GameItem("5", "Call of Duty: Mobile", "com.activision.callofduty.shooter", "FPS", 120, "100%", PerformanceMode.ULTRA_BEAST, true, 180, System.currentTimeMillis() - 43200000, "🎯"),
            GameItem("6", "Honkai: Star Rail", "com.HoYoverse.hkrpgoversea", "Turn-Based RPG", 60, "100%", PerformanceMode.BALANCED, true, 80, System.currentTimeMillis() - 172800000, "🚀")
        )
    )
    val games: StateFlow<List<GameItem>> = _games.asStateFlow()

    private val _prioritySettings = MutableStateFlow(PrioritySettings())
    val prioritySettings: StateFlow<PrioritySettings> = _prioritySettings.asStateFlow()

    private val _boostHistory = MutableStateFlow<List<BoostRecord>>(
        listOf(
            BoostRecord(System.currentTimeMillis() - 3600000, 385, 4820, 4435, 38.6f, 38.1f, 5, System.currentTimeMillis() - 3600000, "Manual"),
            BoostRecord(System.currentTimeMillis() - 10800000, 440, 5100, 4660, 41.2f, 40.5f, 6, System.currentTimeMillis() - 10800000, "Auto Clean")
        )
    )
    val boostHistory: StateFlow<List<BoostRecord>> = _boostHistory.asStateFlow()

    private val _aiOptimization = MutableStateFlow<AiOptimizationResult?>(null)
    val aiOptimization: StateFlow<AiOptimizationResult?> = _aiOptimization.asStateFlow()

    private val _whitelist = MutableStateFlow<Set<String>>(setOf("com.gaming.discord"))
    val whitelist: StateFlow<Set<String>> = _whitelist.asStateFlow()

    var lastAutoCleanTimestamp: Long = 0L
    var lastOverheatNotificationTimestamp: Long = 0L

    fun addGame(game: GameItem) {
        _games.update { current -> current + game }
    }

    fun removeGame(gameId: String) {
        _games.update { current -> current.filterNot { it.id == gameId } }
    }

    fun updateGameConfig(gameId: String, targetFps: Int, mode: PerformanceMode, resolution: String) {
        _games.update { current ->
            current.map {
                if (it.id == gameId) {
                    it.copy(targetFps = targetFps, customMode = mode, resolutionScale = resolution)
                } else it
            }
        }
    }

    fun recordGamePlayed(gameId: String) {
        _games.update { current ->
            current.map {
                if (it.id == gameId) {
                    it.copy(
                        lastPlayedTime = System.currentTimeMillis(),
                        totalPlayTimeMinutes = it.totalPlayTimeMinutes + 25
                    )
                } else it
            }
        }
    }

    fun updatePrioritySettings(newSettings: PrioritySettings) {
        _prioritySettings.value = newSettings
    }

    fun setPerformanceMode(mode: PerformanceMode) {
        _prioritySettings.update { it.copy(mode = mode) }
    }

    fun addBoostRecord(record: BoostRecord) {
        _boostHistory.update { current -> listOf(record) + current.take(19) }
    }

    fun setAiOptimization(result: AiOptimizationResult) {
        _aiOptimization.value = result
    }

    fun toggleAppWhitelist(packageName: String) {
        _whitelist.update { current ->
            if (current.contains(packageName)) current - packageName else current + packageName
        }
    }
}
