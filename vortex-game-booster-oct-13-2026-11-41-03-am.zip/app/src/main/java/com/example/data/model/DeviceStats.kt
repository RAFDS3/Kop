package com.example.data.model

data class RamStats(
    val totalMb: Long,
    val usedMb: Long,
    val freeMb: Long,
    val usagePercent: Int
)

data class BatteryThermalStats(
    val tempCelsius: Float,
    val batteryPercent: Int,
    val isCharging: Boolean,
    val health: String,
    val voltageMv: Int,
    val thermalStatus: ThermalStatus
)

enum class ThermalStatus {
    OPTIMAL,
    WARM,
    OVERHEAT
}

data class CpuStats(
    val loadPercent: Int,
    val coreCount: Int,
    val hardwareModel: String,
    val governor: String
)

data class NetworkPingStats(
    val latencyMs: Int,
    val networkType: String,
    val isConnected: Boolean,
    val quality: String
)

data class DisplayStats(
    val refreshRateHz: Int,
    val resolution: String
)

data class BackgroundApp(
    val name: String,
    val packageName: String,
    val memoryUsageMb: Int,
    val isWhitelisted: Boolean = false,
    val category: String = "Sistem/Latar Belakang"
)
