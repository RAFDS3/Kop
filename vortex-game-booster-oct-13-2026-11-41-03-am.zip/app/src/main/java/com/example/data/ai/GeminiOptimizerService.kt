package com.example.data.ai

import com.example.BuildConfig
import com.example.data.model.AiOptimizationResult
import com.example.data.model.PerformanceMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiOptimizerService {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun analyzeAndOptimizeGame(
        gameTitle: String,
        gameGenre: String,
        currentRamUsedMb: Long,
        totalRamMb: Long,
        currentTempCelsius: Float,
        batteryPercent: Int,
        refreshRateHz: Int
    ): AiOptimizationResult = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val prompt = """
                    Kamu adalah AI System Kernel Optimizer untuk Android Game Booster.
                    Analisis profil perangkat & game berikut:
                    - Game: $gameTitle ($gameGenre)
                    - RAM Saat Ini: $currentRamUsedMb MB digunakan dari $totalRamMb MB
                    - Suhu Perangkat: ${currentTempCelsius}°C
                    - Baterai: $batteryPercent%
                    - Refresh Rate Layar: ${refreshRateHz}Hz

                    Berikan rekomendasi alokasi sumber daya sistem dalam format JSON murni tanpa markdown triple backticks.
                    Format JSON:
                    {
                      "recommendedMode": "ULTRA_BEAST" | "BALANCED" | "BATTERY_SAVER",
                      "suggestedFps": 60 | 90 | 120,
                      "ramBufferAllocationMb": integer_number_mb,
                      "cpuGovernorProfile": "string deskripsi governor",
                      "thermalLimitCelsius": float_suhu_maks,
                      "aiReasoning": "analisis singkat 1-2 kalimat dalam bahasa Indonesia",
                      "inGameTips": ["tip 1", "tip 2", "tip 3"],
                      "estimatedFpsBoostPercent": integer_persentase
                    }
                """.trimIndent()

                val requestJson = JSONObject().apply {
                    val contentsArray = JSONArray().apply {
                        val contentObj = JSONObject().apply {
                            val partsArray = JSONArray().apply {
                                val partObj = JSONObject().apply {
                                    put("text", prompt)
                                }
                                put(partObj)
                            }
                            put("parts", partsArray)
                        }
                        put(contentObj)
                    }
                    put("contents", contentsArray)

                    val genConfig = JSONObject().apply {
                        put("responseMimeType", "application/json")
                        put("temperature", 0.3)
                    }
                    put("generationConfig", genConfig)
                }

                val mediaType = "application/json".toMediaType()
                val requestBody = requestJson.toString().toRequestBody(mediaType)

                val request = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                    .post(requestBody)
                    .build()

                val response = okHttpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    val responseString = response.body?.string() ?: ""
                    val rootJson = JSONObject(responseString)
                    val candidates = rootJson.optJSONArray("candidates")
                    val firstCandidate = candidates?.optJSONObject(0)
                    val content = firstCandidate?.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    val textPart = parts?.optJSONObject(0)?.optString("text")

                    if (!textPart.isNullOrBlank()) {
                        val resultJson = JSONObject(textPart)
                        val modeStr = resultJson.optString("recommendedMode", "ULTRA_BEAST")
                        val mode = when (modeStr) {
                            "BALANCED" -> PerformanceMode.BALANCED
                            "BATTERY_SAVER" -> PerformanceMode.BATTERY_SAVER
                            else -> PerformanceMode.ULTRA_BEAST
                        }
                        val tipsList = mutableListOf<String>()
                        val tipsJson = resultJson.optJSONArray("inGameTips")
                        if (tipsJson != null) {
                            for (i in 0 until tipsJson.length()) {
                                tipsList.add(tipsJson.getString(i))
                            }
                        }

                        return@withContext AiOptimizationResult(
                            gameTitle = gameTitle,
                            recommendedMode = mode,
                            suggestedFps = resultJson.optInt("suggestedFps", 90),
                            ramBufferAllocationMb = resultJson.optInt("ramBufferAllocationMb", 750),
                            cpuGovernorProfile = resultJson.optString("cpuGovernorProfile", "Schedutil Dynamic Priority"),
                            thermalLimitCelsius = resultJson.optDouble("thermalLimitCelsius", 42.0).toFloat(),
                            aiReasoning = resultJson.optString("aiReasoning", "AI menyesuaikan thread CPU khusus untuk $gameTitle agar bebas stutter."),
                            inGameTips = if (tipsList.isNotEmpty()) tipsList else getDefaultTips(gameTitle),
                            estimatedFpsBoostPercent = resultJson.optInt("estimatedFpsBoostPercent", 18)
                        )
                    }
                }
            } catch (_: Exception) {
                // Fallback to local heuristic engine
            }
        }

        // Offline / Fallback Intelligent Heuristic Engine
        generateLocalHeuristicProfile(
            gameTitle = gameTitle,
            gameGenre = gameGenre,
            currentTemp = currentTempCelsius,
            totalRamMb = totalRamMb,
            refreshRate = refreshRateHz
        )
    }

    private fun generateLocalHeuristicProfile(
        gameTitle: String,
        gameGenre: String,
        currentTemp: Float,
        totalRamMb: Long,
        refreshRate: Int
    ): AiOptimizationResult {
        val isHeavy = gameTitle.contains("Genshin", ignoreCase = true) ||
                gameTitle.contains("PUBG", ignoreCase = true) ||
                gameTitle.contains("Warzone", ignoreCase = true) ||
                gameGenre.contains("Battle Royale", ignoreCase = true) ||
                gameGenre.contains("Action RPG", ignoreCase = true)

        val mode: PerformanceMode
        val targetFps: Int
        val bufferMb: Int
        val cpuGov: String
        val reasoning: String
        val boostPercent: Int

        when {
            currentTemp >= 41.5f -> {
                mode = PerformanceMode.BALANCED
                targetFps = 60
                bufferMb = (totalRamMb * 0.15).toInt().coerceIn(400, 900)
                cpuGov = "Thermal Throttling Shield (Cap 85% Core Freq)"
                reasoning = "Suhu perangkat terdeteksi ${String.format("%.1f", currentTemp)}°C. AI memprioritaskan kestabilan frame rate 60 FPS untuk mencegah thermal drop tajam."
                boostPercent = 14
            }
            isHeavy -> {
                mode = PerformanceMode.ULTRA_BEAST
                targetFps = if (refreshRate >= 90) 90 else 60
                bufferMb = (totalRamMb * 0.22).toInt().coerceIn(600, 1400)
                cpuGov = "High-Performance Cluster Locking (Core Affinity Gaming)"
                reasoning = "Game $gameTitle membutuhkan alokasi GPU shader tinggi. AI mengunci resource pool RAM $bufferMb MB eksklusif untuk proses game."
                boostPercent = 24
            }
            else -> {
                mode = PerformanceMode.ULTRA_BEAST
                targetFps = if (refreshRate >= 120) 120 else if (refreshRate >= 90) 90 else 60
                bufferMb = (totalRamMb * 0.18).toInt().coerceIn(500, 1000)
                cpuGov = "Adaptive Low-Latency Scheduler"
                reasoning = "Game kompetitif $gameTitle diprioritaskan pada responsivitas sentuhan dan latensi render frame terendah."
                boostPercent = 20
            }
        }

        return AiOptimizationResult(
            gameTitle = gameTitle,
            recommendedMode = mode,
            suggestedFps = targetFps,
            ramBufferAllocationMb = bufferMb,
            cpuGovernorProfile = cpuGov,
            thermalLimitCelsius = 42.5f,
            aiReasoning = reasoning,
            inGameTips = getDefaultTips(gameTitle),
            estimatedFpsBoostPercent = boostPercent
        )
    }

    private fun getDefaultTips(gameTitle: String): List<String> {
        return when {
            gameTitle.contains("Genshin", ignoreCase = true) -> listOf(
                "Nyalakan Render Resolution ke Medium dan Frame Rate ke 60 FPS untuk kestabilan tertinggi.",
                "Nonaktifkan Motion Blur di pengaturan dalam game untuk mengurangi beban GPU.",
                "Aktifkan Mode Prioritas Vortex untuk memblokir chat popup yang memicu frame drop."
            )
            gameTitle.contains("Mobile Legends", ignoreCase = true) -> listOf(
                "Gunakan Grafis Tinggi dengan Mode High Frame Rate (HFR) Ultra di menu game.",
                "Aktifkan fitur Network Priority di Vortex untuk mengurangi latensi Wi-Fi / 4G.",
                "Tutup aplikasi media sosial latar belakang agar ping tetap hijau di bawah 30ms."
            )
            gameTitle.contains("PUBG", ignoreCase = true) || gameTitle.contains("Free Fire", ignoreCase = true) -> listOf(
                "Atur grafik ke 'Smooth' dan frame rate ke 'Extreme' / '90 FPS'.",
                "Nonaktifkan bayangan berlebih (Shadows) untuk deteksi musuh lebih tajam dan stabil.",
                "Kunci kecerahan layar dengan Vortex agar tidak berkedip saat rotasi ponsel."
            )
            else -> listOf(
                "Bersihkan cache latar belakang sebelum memulai match rank.",
                "Pastikan baterai tidak di bawah 20% untuk menghindari power throttle otomatis Android.",
                "Gunakan jaringan Wi-Fi 5GHz atau sinyal seluler prima untuk latensi terendah."
            )
        }
    }
}
