package com.example.data.model

data class GameItem(
    val id: String,
    val name: String,
    val packageName: String,
    val category: String,
    val targetFps: Int = 90,
    val resolutionScale: String = "100%",
    val customMode: PerformanceMode = PerformanceMode.ULTRA_BEAST,
    val isAutoBoostOnLaunch: Boolean = true,
    val totalPlayTimeMinutes: Int = 0,
    val lastPlayedTime: Long = 0L,
    val iconEmoji: String = "🎮"
)

data class BoostRecord(
    val id: Long = System.currentTimeMillis(),
    val freedRamMb: Int,
    val previousRamUsedMb: Long,
    val newRamUsedMb: Long,
    val temperatureBefore: Float,
    val temperatureAfter: Float,
    val appsClosedCount: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val triggerSource: String = "Manual"
)

data class AiOptimizationResult(
    val gameTitle: String,
    val recommendedMode: PerformanceMode,
    val suggestedFps: Int,
    val ramBufferAllocationMb: Int,
    val cpuGovernorProfile: String,
    val thermalLimitCelsius: Float,
    val aiReasoning: String,
    val inGameTips: List<String>,
    val estimatedFpsBoostPercent: Int,
    val timestamp: Long = System.currentTimeMillis()
)
